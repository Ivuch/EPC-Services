package com.hawaii.epc;


import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;

@Named
@Slf4j
@SessionScoped
public class EmpiezaAqui implements Serializable {
	
	@Inject
	EmpiezaAquiTienda tienda;
	
	private String companyName = "Enterprise";
	
	
	public EmpiezaAqui() {

		
		String myDescription = "Mate";
		

		log.debug("DEBUG HAWAII");
		
		
		log.info(myDescription);
		//EmpiezaAquiTienda tienda2 = new EmpiezaAquiTienda();
		myDescription = tienda.getMyDescription();
		
		this.setCompanyName(myDescription);
		
	}
	
	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	
}
